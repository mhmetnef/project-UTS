package com.example.utsproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
